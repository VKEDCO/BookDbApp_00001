/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.mobappdev.simple_db_app_01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}